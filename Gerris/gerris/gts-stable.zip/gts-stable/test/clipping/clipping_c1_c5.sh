#! /bin/sh
./clipping.sh c1 c5

