#! /bin/sh
./clipping.sh l1 l2

